<?php

namespace App\Repository;

use App\Entity\Category;
use Doctrine\Persistence\ManagerRegistry;
use Doctrine\ORM\EntityRepository;

class CategoryRepository extends EntityRepository
{
  public function getAllCategories(): array
  {
    return $this->findAll(); // Получаем все категории
  }
}
